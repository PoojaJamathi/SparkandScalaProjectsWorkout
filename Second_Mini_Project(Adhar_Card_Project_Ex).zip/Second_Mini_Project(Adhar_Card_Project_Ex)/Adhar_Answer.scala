import org.apache.log4j.{Level, Logger}
import org.apache.spark.SparkContext
import org.apache.spark.sql.cassandra._
import org.apache.spark.sql.{DataFrame, Row, SQLContext, SparkSession}
import org.apache.spark.sql.functions._
import org.joda.time.DateTime
import org.apache.spark.sql.types.IntegerType
import java.sql.Date
import java.sql.Timestamp
import java.time.LocalDate
import java.text.SimpleDateFormat
import java.util.Calendar


object Demo1 {
  var sc: SparkContext = null
  var sqlContext: SQLContext = null
  var spark: SparkSession = null
  def main(args:Array[String]): Unit ={
    println("Hello");
    spark = SparkSession.builder.appName("POS").config("spark.cassandra.connection.host", "5.9.58.93").master("local[6]").getOrCreate()
    spark.conf.set("spark.executor.memory", "3g")
    spark.conf.set("spark.driver.memory", "3g")
    spark.conf.set("spark.cassandra.connection.host", "5.9.58.93")
    val startDate: DateTime = DateTime.now()
    sc = spark.sparkContext
    sqlContext = new SQLContext(sc) //10.87.88.133

    var uidEnrolmentDF = spark.read.format("com.databricks.spark.csv").option("header", "true").option("delimiter",",").load("C:\\Users\\Aakash Kumar\\Desktop\\UIDAI-ENR-DETAIL-20170308.csv")

    uidEnrolmentDF.registerTempTable("uid_enrolments_detail")

    val stateWiseCountDF = spark.sql("""SELECT State,SUM(`Aadhaar generated`) as count FROM uid_enrolments_detail GROUP BY state ORDER BY count DESC""".stripMargin)

    //stateWiseCountDF.show()

    //stateWiseCountDF.write.mode("overwrite").saveAsTable("uid.state_wise_count")

    val maxEnrolmentAgencyDF = spark.sql("""SELECT `Enrolment Agency` as Enrolment_Agency,SUM(`Aadhaar generated`) as count FROM uid_enrolments_detail GROUP BY `Enrolment Agency` ORDER BY count DESC""".stripMargin)

    //maxEnrolmentAgencyDF.show()

    // maxEnrolmentAgencyDF.write.mode("overwrite").saveAsTable("uid.agency_wise_count")

    val districtWiseGenderCountDF = spark.sql(""" SELECT District,count(CASE WHEN Gender='M' THEN 1 END) as male_count,count(CASE WHEN Gender='F' THEN 1 END) as FEMALE_count FROM uid_enrolments_detail GROUP BY District ORDER BY male_count DESC, FEMALE_count DESC LIMIT 10""".stripMargin)

    districtWiseGenderCountDF.show()

    //districtWiseGenderCountDF.write.mode("overwrite").saveAsTable("uid.district_wise_gndr_count")