# Analytical Query

### Make production level tables in datalake for Movielens in spark

Run the following code to view output

```
sh execute.sh
```
