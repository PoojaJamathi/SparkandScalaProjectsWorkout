#!/usr/bin/env bash
spark-shell -i make_datalake.scala
echo ""
echo "Exiting script"
echo ""	
