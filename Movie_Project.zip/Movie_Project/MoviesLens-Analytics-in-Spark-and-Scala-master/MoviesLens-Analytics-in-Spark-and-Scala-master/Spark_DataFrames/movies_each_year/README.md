# Analytical Query 

### Find the number of movies released each year

Run the following code to view output

```
sh execute.sh
```
