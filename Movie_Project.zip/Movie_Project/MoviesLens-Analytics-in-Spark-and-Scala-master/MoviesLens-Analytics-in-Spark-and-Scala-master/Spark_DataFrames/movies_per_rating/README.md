# Analytical Query 

### Find the number of movies for each rating

Run the following code to view output

```
sh execute.sh
```
