# Analytical Query 

### For each movie, How many users rated it? What is the total rating? What is the average rating?

Run the following code to view output

```
sh execute.sh
```
